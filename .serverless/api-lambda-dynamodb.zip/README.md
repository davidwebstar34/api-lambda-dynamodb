### Serverless deployment of Api gateway, Lambda and Dynamodb 

> sls deploy

> sls invoke local -f getDynamo
